// Generated using https://github.com/a2x/cs2-dumper
// 2026-09-02 06:43:55.090478200 UTC

namespace CS2Dumper.Schemas {
    // Module: networksystem.dll
    // Class count: 1
    // Enum count: 0
    public static class NetworksystemDll {
        // Parent: None
        // Field count: 1
        public static class ChangeAccessorFieldPathIndex_t {
            public const nint m_Value = 0x0; // int32
        }
    }
}
